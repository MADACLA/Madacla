@echo off
rem Arranca la caja de Madacla: el programa (caja.py) y la pantalla a
rem pantalla completa en Chrome o Edge. Doble clic y listo.
rem Si ya estaba arrancado, solo abre la pantalla otra vez.

cd /d "%~dp0"
title Caja Madacla - arrancando

rem ---- 1. buscar Python (vale el instalador nuevo de python.org y el clasico)
set "PY="
if exist "%LOCALAPPDATA%\Python\bin\python.exe" set "PY=%LOCALAPPDATA%\Python\bin\python.exe"
if not defined PY for /d %%d in ("%LOCALAPPDATA%\Python\pythoncore-*") do if exist "%%d\python.exe" set "PY=%%d\python.exe"
if not defined PY for /d %%d in ("%LOCALAPPDATA%\Programs\Python\Python3*") do if exist "%%d\python.exe" set "PY=%%d\python.exe"
if not defined PY for /d %%d in ("%ProgramFiles%\Python3*") do if exist "%%d\python.exe" set "PY=%%d\python.exe"
if not defined PY where python.exe >nul 2>&1 && set "PY=python"
if not defined PY (
    echo.
    echo   NO ENCUENTRO PYTHON EN ESTE ORDENADOR.
    echo   Haz una foto de esta ventana y mandala.
    echo.
    dir "%LOCALAPPDATA%\Python" 2>nul
    pause
    exit /b 1
)
echo Python: %PY%

rem ---- 2. arrancar el programa si no esta ya
netstat -ano | findstr /r /c:":8791 .*LISTENING" >nul
if not errorlevel 1 goto listo
start "Caja Madacla (no cerrar)" /min cmd /c "%~dp0caja-bucle.cmd"
echo Arrancando el programa de la caja...
set /a n=0
:espera
timeout /t 1 /nobreak >nul
netstat -ano | findstr /r /c:":8791 .*LISTENING" >nul
if not errorlevel 1 goto listo
set /a n+=1
if %n% lss 60 goto espera
echo.
echo   EL PROGRAMA NO HA ARRANCADO EN UN MINUTO.
echo   Mira la ventana "Caja Madacla (no cerrar)" en la barra de abajo,
echo   haz una foto de lo que pone y mandala. Esto es el registro:
echo.
type registro-caja.txt 2>nul
pause
exit /b 1
:listo

rem ---- 3. abrir la pantalla
set "NAV="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "NAV=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "NAV=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined NAV if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "NAV=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not defined NAV if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "NAV=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"

if not defined NAV (
    start http://127.0.0.1:8791/
) else (
    start "" "%NAV%" --app=http://127.0.0.1:8791/ --start-fullscreen --disable-pinch --user-data-dir="%LOCALAPPDATA%\CajaMadacla" --no-first-run --disable-session-crashed-bubble
)
