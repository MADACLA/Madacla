@echo off
rem El bucle de la caja: lo abre arrancar-caja.cmd en la ventana
rem "Caja Madacla (no cerrar)". Si la caja se reinicia tras actualizarse
rem (sale con codigo 3), la vuelve a abrir. Si la version nueva se cae,
rem vuelve a la anterior (anteriores\ultima) y apunta la mala para no
rem volver a ponerla.
cd /d "%~dp0"
title Caja Madacla (no cerrar)
set CAJA_BUCLE=1
if not defined PY set "PY=python"
:otra
"%PY%" caja.py
set CODIGO=%errorlevel%
if "%CODIGO%"=="3" goto otra
if exist "anteriores\ultima\caja.py" (
    echo La version nueva de la caja ha fallado: vuelvo a la anterior.
    copy /y version.txt "anteriores\mala.txt" >nul
    copy /y "anteriores\ultima\*" . >nul
    rmdir /s /q "anteriores\ultima"
    timeout /t 3 /nobreak >nul
    goto otra
)
echo.
echo   EL PROGRAMA DE LA CAJA SE HA PARADO (codigo %CODIGO%).
echo   Haz una foto de esta ventana y mandala. Para volver a abrirla,
echo   doble clic en el icono Caja del escritorio.
pause
