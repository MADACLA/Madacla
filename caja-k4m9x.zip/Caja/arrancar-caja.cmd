@echo off
rem Arranca la caja de Madacla: el programa (caja.py) y la pantalla a
rem pantalla completa en Chrome o Edge. Doble clic y listo.
rem Si ya estaba arrancado, solo abre la pantalla otra vez.

cd /d "%~dp0"

netstat -ano | findstr /r ":8791 .*LISTENING" >nul
if errorlevel 1 (
    start "Caja Madacla" /min python caja.py
    timeout /t 2 /nobreak >nul
)

set NAV=
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set NAV=%ProgramFiles%\Google\Chrome\Application\chrome.exe
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set NAV=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe
if "%NAV%"=="" if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set NAV=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe
if "%NAV%"=="" if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set NAV=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe

if "%NAV%"=="" (
    start http://127.0.0.1:8791/
) else (
    start "" "%NAV%" --app=http://127.0.0.1:8791/ --start-fullscreen --user-data-dir="%LOCALAPPDATA%\CajaMadacla" --no-first-run --disable-session-crashed-bubble
)
