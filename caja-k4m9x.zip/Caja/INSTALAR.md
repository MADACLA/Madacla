# Instalar la caja en el Lenovo de la tienda

Todo esto se hace UNA vez, con Claudia y Claude juntas. Después, Maricarmen
solo hace doble clic en el icono «Caja Madacla» del escritorio (o ni eso: se
abre sola al encender).

## 1. Python

1. Abrir `https://www.python.org/downloads/windows/` y bajar la última
   versión de Python 3 (botón grande «Download Python 3.x»).
2. Al instalar, marcar la casilla **«Add python.exe to PATH»** (abajo del
   todo de la primera pantalla) y luego «Install Now».

## 2. La carpeta de la caja

1. Copiar la carpeta `caja` entera (esta) a `C:\Caja` en el Lenovo
   (pendrive, o desde GitHub: solo hace falta esta carpeta).
2. Dentro, copiar `config.ejemplo.json` y llamarlo `config.json`.
3. Abrirlo con el Bloc de notas y rellenar:
   - `"nif"`: el NIF de Mari Carmen.
   - `"pin"`: los 4 números del PIN.
   - `"impresora"`: el nombre EXACTO de la impresora de tickets tal y como
     sale en Windows (Configuración → Bluetooth y dispositivos → Impresoras).
     Mientras no haya impresora, dejarlo vacío `""`: la caja funciona igual
     y enseña el ticket en pantalla.
   - `"carpeta_drive"`: la carpeta de Google Drive donde guardar las copias,
     por ejemplo `"G:\Mi unidad\Caja Madacla"` (ver punto 4). Vacío = solo
     copias en este ordenador.
4. Guardar.

## 3. Probar

Doble clic en `arrancar-caja.cmd`. Debe abrirse la pantalla de la caja a
pantalla completa. Hacer una venta de prueba y luego anularla (PIN).

Para salir de la pantalla completa: tecla `F11` o `Alt + F4`.

## 4. Google Drive (copias de seguridad fuera de la tienda)

1. Instalar «Google Drive para ordenadores» (`https://www.google.com/drive/download/`).
2. Entrar con la cuenta de Gmail de la tienda.
3. Crear en Mi unidad una carpeta «Caja Madacla» y poner su ruta en
   `config.json` (`carpeta_drive`).
4. La caja copia ahí la base de datos cada 6 horas y en cada cierre, y el
   Excel del mes cada vez que se exporta.

## 5. Que arranque sola al encender

1. Tecla Windows + R, escribir `shell:startup` y Aceptar.
2. Botón derecho sobre `arrancar-caja.cmd` → «Crear acceso directo», y
   arrastrar ese acceso directo a la carpeta que se ha abierto.
3. Poner otro acceso directo en el escritorio y llamarlo «Caja Madacla».

## 6. La impresora de tickets (cuando llegue el adaptador)

1. Conectar la Bixolon por el adaptador USB-paralelo y encenderla.
2. Windows la detecta como «USB Printing Support». En Configuración →
   Impresoras → «Agregar dispositivo» → «Agregar manualmente» → puerto
   `USB001` → fabricante «Generic» → «Generic / Text Only».
3. Llamarla `Tickets` y poner ese nombre en `config.json`.
4. Reiniciar la caja (cerrar la ventana negra «Caja Madacla» y volver a
   hacer doble clic). Debe salir «Impresora lista» arriba.
5. El cajón va enchufado al conector RJ11 de la impresora: se abre solo al
   cobrar en efectivo.

## Dónde está cada cosa

- `datos/ventas.sqlite`: TODAS las ventas. No se puede borrar ni cambiar
  nada desde el programa (la base de datos lo prohíbe). No tocarlo.
- `copias/`: copias de seguridad y los Excel (`ventas-2026-09.csv`) por mes.
  Se abren con Excel; el separador es punto y coma.
- `registro-caja.txt`: lo que ha ido pasando (ventas, cierres, errores).
